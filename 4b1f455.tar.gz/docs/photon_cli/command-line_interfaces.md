# Command-line Interfaces

Photon OS includes the following command-line utilities:

- [Photon Management Daemon Command-line Interface (pmd-cli)](pmd-cli.md). The pmd-cli utility enables Photon customers to invoke API requests securely on local and remote servers. 
- [Photon Network Manager Command-line Interface (netmgr)](netmgr-cli.md). A command line interface to manage network configuration of the system.
