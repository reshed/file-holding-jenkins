# Installing the pmd Package

The pmd package is included with your Photon OS 3.0 distribution. To make sure that you have the latest version, you can run:
~~~~
# tdnf install pmd
# systemctl start pmd
~~~~