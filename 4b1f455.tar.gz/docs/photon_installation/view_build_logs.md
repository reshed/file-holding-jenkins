# View Build Logs

You can view build logs at the following location:

```
$HOME/workspaces/photon/stage/LOGS
```
