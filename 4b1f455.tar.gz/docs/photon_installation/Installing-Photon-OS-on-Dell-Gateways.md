# Installing Photon OS on Dell Gateways

You can isntall Photon OS on Dell Edge Gateways 500X and 300X. 

Dell Edge Gateways are devices that aggregate, secure, analyze, and relay data from diverse sensors and equipment at the edge of the IOT network.


- [Installing Photon OS on Dell Edge Gateway 500X](Installing-Photon-OS-on-Dell-500X.md)
- [Installing Photon OS on Dell Edge Gateway 300X](Installing-Photon-OS-on-Dell-300X.md)

For more information about Dell Gateways, see [Dell Edge Gateways for IOT](https://www.dell.com/en-us/work/shop/gateways-embedded-computing/sf/edge-gateway)
