# Running Photon OS on Raspberry Pi 3

You can use Photon OS as a virtual machine on Raspberry Pi 3 (RPi3). You can download Photon OS and install the Photon OS distribution on vSphere. 

- [Prerequisites](photon-os-rpi3-prerequisites.md)
- [Installing Photon OS on Raspberry Pi 3](installing-the-iso-image-for-photon-os-30-rpi3.md)
- [Enabling Rpi3 Interfaces using Device Tree](enabling_RPi3_interfaces_using_devicetree.md)
