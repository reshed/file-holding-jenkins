# System Information

Hosts:

```
photon-master = 192.168.121.9
photon-node = 192.168.121.65
```