# Prerequisites

You need two or more machines with the 3.0 general availability or later version of Photon OS installed.