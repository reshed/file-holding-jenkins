# Standard Syntax for `tdnf` Commands 

The standard syntax for `tdnf` commands is the same as that for DNF and is as follows: 

	tdnf [options] <command> [<arguments>...]

You can view help information by using the following commands: 

	tdnf --help
	tdnf -h