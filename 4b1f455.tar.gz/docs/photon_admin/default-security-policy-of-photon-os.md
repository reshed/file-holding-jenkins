# Security Policy

This section describes the security policy of Photon OS.

-   [Default Firewall Settings](default-firewall-settings.md)
-   [Default Permissions and umask](default-permissions-and-umask.md)
-   [Disabling TLS 1.0 to Improve Transport Layer Security](disabling-tls-1.0.md)