# Linux Troubleshooting Tools

The following Linux troubleshoot tools are neither installed on Photon OS by default nor available in the Photon OS repositories: 

* iostat
* telnet (use SSH instead)
* Iprm
* hdparm
* syslog (use journalctl instead)
* ddd
* ksysmoops
* xev
* GUI tools (because Photon OS has no GUI)