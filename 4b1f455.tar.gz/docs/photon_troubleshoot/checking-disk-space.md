# Checking Disk Space

One of the first simple steps to take while troubleshooting is to check how much disk space is available by running the `df` command: 

	df -h