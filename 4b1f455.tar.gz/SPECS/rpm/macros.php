# PHP specific macro definitions.

%php_pear_dir	%{_datadir}/pear
